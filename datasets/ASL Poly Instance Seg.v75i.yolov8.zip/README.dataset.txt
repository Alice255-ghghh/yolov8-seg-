# ASL Poly Instance Seg > 2025-01-17 6:27pm
https://universe.roboflow.com/paul-guerrie-tang1/asl-poly-instance-seg

Provided by a Roboflow user
License: undefined

